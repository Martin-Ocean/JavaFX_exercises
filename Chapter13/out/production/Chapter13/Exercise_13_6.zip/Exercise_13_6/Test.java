package Exercise_13_6;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        double radius1, radius2;

        Scanner in = new Scanner(System.in);
        // prompt for two circle radius
        System.out.println("Please enter two radius: ");

        radius1 = in.nextDouble();
        radius2 = in.nextDouble();
        // Create two instances of ComparableCircle objects
        ComparableCircle circle1 = new ComparableCircle(radius1);
        ComparableCircle circle2 = new ComparableCircle(radius2);


        // Find and display the larger of the two ComparableCircle objects
        System.out.println((circle1.compareTo(circle2) == 1
                ? "\nCircle1 has "+ circle1.getArea() : "\nCircle2 has \n\t" + circle2.getArea()) +
                "\nis the larger one");
    }
}
