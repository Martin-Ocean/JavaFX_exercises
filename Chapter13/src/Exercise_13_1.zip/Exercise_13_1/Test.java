package Exercise_13_1;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        System.out.println("Please enter three sides: ");
        Scanner in = new Scanner(System.in);
        String color;
        boolean filled = false;
        double a,b,c;
        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();
        System.out.println("Enter a color: ");
        color = in.next();

        System.out.println("Is it filled? \n1 True\n2 False");
        if (in.nextInt() == 1) filled = true;

        GeometricObject triangle = new Triangle(a,b,c,color,filled);

        triangle.print();
    }
}
