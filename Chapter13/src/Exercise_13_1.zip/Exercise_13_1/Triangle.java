package Exercise_13_1;

public class Triangle extends GeometricObject {
    private String color;
    private boolean filled;
    private double A, B, C;
    public Triangle() {
    }

    public Triangle(double A, double B, double C) {
        this.A = A;
        this.B = B;
        this.C = C;
    }

    public Triangle(double A, double B, double C, String color, boolean filled) {
        this.A = A;
        this.B = B;
        this.C = C;
        this.color = color;
        this.filled = filled;
    }
    @Override
    public double getArea() {
        double p = getPerimeter()/2.0;
        return Math.pow( (p*(p-A)*(p-B)*(p-C)), .5);
    }

    @Override
    public double getPerimeter() {
        return A+B+C;
    }

    @Override
    public void print() {
        System.out.println("Triangle area is: " + getArea() +"\nPerimeter is : "+getPerimeter()+"\ncolor: " + color + "\t filled: "+ filled);
    }
}